﻿var bk_displayed_selector='.bibDisplayContentMain';
var loc_3d = 'http://121.49.98.194:8080/dzkj/TSDW/GotoFlash.aspx?szBarCode=';//3D定位url